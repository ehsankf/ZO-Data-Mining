mex Alg_SVRGI.cpp  -largeArrayDims;
mex Alg_SVRGII.cpp  -largeArrayDims;
mex Alg_VRSGDI.cpp  -largeArrayDims;
mex Alg_VRSGDII.cpp  -largeArrayDims;
mex Alg_KatyushaI.cpp  -largeArrayDims;
mex Alg_KatyushaII.cpp  -largeArrayDims;
