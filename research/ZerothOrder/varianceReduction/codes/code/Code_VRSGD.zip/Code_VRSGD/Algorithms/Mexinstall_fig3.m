mex Alg_SVRG.cpp  -largeArrayDims;
mex Alg_Katyusha.cpp  -largeArrayDims;
mex Alg_VRSGD.cpp  -largeArrayDims;
mex Alg_AGD.cpp -largeArrayDims;
mex Alg_SGD.cpp -largeArrayDims;