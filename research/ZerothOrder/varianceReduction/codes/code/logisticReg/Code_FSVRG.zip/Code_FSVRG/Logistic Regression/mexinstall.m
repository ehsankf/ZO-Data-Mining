mex Alg_SVRG.cpp  -largeArrayDims
mex Alg_FSVRG.cpp  -largeArrayDims
mex Alg_SVRGAA.cpp  -largeArrayDims
mex Alg_Katyusha.cpp  -largeArrayDims

