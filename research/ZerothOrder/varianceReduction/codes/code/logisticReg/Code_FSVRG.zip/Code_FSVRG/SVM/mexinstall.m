mex Alg_SSGD.cpp
mex Alg_SVRG.cpp
mex Alg_FSVRG.cpp
